import domainConfig from "../src/domainConfig.js";

export default {
    widgetConfig: [
        {
          widgetUUID: domainConfig().widget_uuid
        }
    ]
};
