import { hooks as campaignHooks } from "../../models/campaign.js";

export var allHooks = {
	campaign: campaignHooks,
};
