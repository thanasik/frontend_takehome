export default {
    "testRegex": "((\\.|/*\\.)(test))\\.js?$",
};
